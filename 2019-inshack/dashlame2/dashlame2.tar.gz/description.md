This challenge is in two parts. You can find the first (easy) part in the Reverse Engineering category.

I've lost my master key... Please help me recover the credentials from my [archive](https://static.ctf.insecurity-insa.fr/11c0fb2a76b074bfa78516cde464cdc9d8cf0eb4.tar.gz) !