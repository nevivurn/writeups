Can you try our new [password manager](https://static.ctf.insecurity-insa.fr/66b6d135a7e86758803a93f20f6fd7171a7d8e45.tar.gz) ? There's a free flag in every password archive created !

This challenge contains a second part in the Crypto category.